"""Where delivery state lives."""
