"""Interfaces that adapters implement."""
